import gym
import tensorflow as tf
import numpy as np
import pandas as pd
from gym.spaces import Discrete
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
from sklearn.preprocessing import OneHotEncoder
from predictmodel import PredictModel


class Environment(gym.Env):
    def __init__(self,total_feature_num,train_file,test_file, model):
        self.total_feature_num = total_feature_num        # 总的特征个数
        self.action_space = Discrete(total_feature_num)   # 离散化动作空间
        self.n_action = self.action_space.n
        self.state = [1] * total_feature_num
        self.train_data, self.train_label, self.test_data, self.test_label = DataLoad(train_file, test_file)
        self.state_memory = []
        self.reward_memory = []
        self.model = model

    def reset(self):
        init = [1] * self.total_feature_num
        self.state = np.array(init)
        return self.state

    def step(self,a):
        reward2 = 0.0
        temp = []
        act = [0]*a + [1] + [0]*(self.total_feature_num-a-1)  #将动作转换为一个由0和1组成的列表（act），其中第a个位置上是1，其余位置上是0。
        for i in range(len(act)):
            temp.append((act[i]+self.state[i]) % 2)
        last_state = self.state
        self.state = np.array(temp)
        if temp not in self.state_memory:
            reward = get_reward(self.train_data, self.train_label, self.test_data, self.test_label, cols=self.state, model=self.model)
            acc1 = get_reward(self.train_data, self.train_label, self.test_data, self.test_label, cols=last_state, model=self.model)
            if abs(acc1) > abs(reward):
                reward2 = abs(acc1) - abs(reward)
            elif abs(acc1) <= abs(reward):
                reward2 = abs(acc1) - abs(reward)

            self.state_memory.append(temp)
            self.reward_memory.append(reward2)

        else:
            index = self.state_memory.index(temp)
            reward = self.reward_memory[index]
        print(self.state)

        if sum(self.state) == 4:
            done = 1
        else:
            done = 0
        return self.state,reward,done,{}

def DataLoad(train_file, test_file, random_seed=False):
    train_data = pd.read_csv(train_file, header=None)
    test_data = pd.read_csv(test_file, header=None)

    if random_seed is not False:
        np.random.seed(random_seed)
    index = np.arange(train_data.shape[0])
    np.random.shuffle(index)
    train_data = train_data.iloc[index]
    train_label = train_data.iloc[:, -1]
    train_data = train_data.iloc[:, 0:-1]
    test_label = test_data.iloc[:, -1]
    test_data = test_data.iloc[:, 0:-1]

    return train_data, train_label, test_data, test_label


def get_reward(train_data,train_label,test_data,test_label,cols,model):

    reward = PredictModel(cols,train_data,train_label,test_data,test_label).\
        lstm_predict(batch_size=24, learning_rate=0.04, model=model)

    return reward


