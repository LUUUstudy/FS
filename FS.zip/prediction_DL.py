from keras.models import load_model, Model
from keras.layers import Input, Dense

class Prediction:

    def __init__(self, data_test, label_test):
        """
            深度学习模型的预测

            Args:
                data_test: 测试集样本
                label_test: 测试集标签
        """

        self.data_test = data_test
        self.label_test = label_test

    def prediction(self, model, batch_size):
        """
            根据提供的模型进行测试集的预测

            Args:
                model: 训练完成的深度学习模型
                batch_size: 执行单步预测，默认为1

            Returns:
                y_pred: 测试集的预测结果
        """

        y_pred = model.predict(self.data_test, batch_size=batch_size)
        return y_pred
