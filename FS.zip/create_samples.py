import numpy as np
import csv

class CreateSample:
    """
    输入：
        test3W_new.csv
        由能耗、天气、时间戳信息组成的矩阵

    输出：
        第一种样本池 前 features 小时的能耗构成一个样本
    """

    # def createFirstSample(self, data, shape, features):
    #     """
    #         构建第一种样本池：前 time 小时预测下一小时的能耗
    #
    #         Args:
    #             data: 待构建样本池的数据，矩阵形式
    #             shape: 单个样本是向量（能耗数据）还是矩阵（能耗数据，天气，日期）
    #
    #         Returns:
    #             samples_time: 预测样本的列表
    #             targets_time: 预测样本对应的真实值标签列表
    #     """
    #     print("********* 使用第一样本池 *********")
    #     print("历史能耗数据构成的特征数为：", features)
    #
    #     samples_time = []
    #     targets_time = []
    #
    #     for j in np.arange(features+1, len(data), 1):
    #
    #         sample_temp = []  # 帮助构建样本
    #
    #         for i in range(j - features, j, 1):
    #
    #             if shape == "vector":
    #                 sample_temp.append(data[i][0])
    #             elif shape == "matrix":
    #                 sample_temp.append(data[i])
    #
    #         samples_time.append(sample_temp)
    #         targets_time.append(data[j][0])
    #
    #     return samples_time, targets_time

    def createFirstSample(self, data, features, state):
        """
            构建第二种样本池：前 time 小时+其他天气等特征预测下一小时的能耗

            Args:
                data: 待构建样本池的数据，矩阵形式
                shape: 单个样本是向量（能耗数据）还是矩阵（能耗数据，天气，日期）

            Returns:
                samples_time: 预测样本的列表
                targets_time: 预测样本对应的真实值标签列表
        """
        print("********* 使用第一样本池 *********")
        print("历史能耗数据构成的特征数为：", features)

        samples_time = []
        targets_time = []

        filename = 'data/input.csv'

        with open(filename, newline='') as csvfile:
            reader = csv.reader(csvfile)
            data1 = list(reader)  # 读取CSV文件中的数据到二维列表中

        # 按照state的取值，从data中选择列
        result = [data1[i] for i in range(len(state)) if state[i] == 1]

        # 将result写入新的CSV文件中
        with open('data/output.csv', 'w', newline='') as csvfile:
            writer = csv.writer(csvfile)
            for row in result:
                writer.writerow(row)

        with open('output.csv', newline='') as csvfile:
            reader = csv.reader(csvfile)
            data2 = list(reader)  # 读取CSV文件中的数据到二维列表中
        # 将data转换为数组列表形式
        samples_time.append(data2)

        # with open(filename, 'r') as f:
        #     reader = csv.reader(f)
        #     for row in reader:
        #         # 将前24列和后12列分别组成两个列表
        #         features = [float(value) for value in row[:24]]
        #         targets = [float(value) for value in row[24:]]
        #         # 将两个列表合并为一个13维的列表
        #         merged_row = features + targets
        #         samples_time.append(merged_row)

        for j in np.arange(features+1, len(data), 1):
            targets_time.append(data[j][0])

        return samples_time, targets_time
