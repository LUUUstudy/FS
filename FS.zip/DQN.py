import numpy as np
import tensorflow as tf
import random
from matplotlib import rcParams
np.random.seed(20230407)
tf.compat.v1.set_random_seed(20230407)
import matplotlib.pyplot as plt
rcParams['font.family'] = 'serif'
rcParams['font.serif'] = ['Times New Roman']

class DeepQNetwork(object):
    def __init__(
            self,
            n_actions,
            n_features,
            learning_rate = 0.01, # DQN的参数更新学习率
            reward_decay = 0.9, # 回报折扣率
            e_greedy = 0.9, # e-贪心探索的概率
            memory_size = 1000, # Replay Buffer的容量
            replace_target_iter = 300,
            batch_size = 32,
            e_greedy_increment = 0.0005,
            output_graph = False,
            ):
        self.n_actions = n_actions
        self.n_features = n_features
        self.lr = learning_rate
        self.gamma = reward_decay
        self.epsilon_max = e_greedy
        self.replace_target_iter = replace_target_iter
        self.memory_size = memory_size
        self.batch_size = batch_size
        self.epsilon_increment = e_greedy_increment
        self.epsilon = 0.9
        # self.epsilon = 0 if e_greedy_increment is not None else self.epsilon_max
        self.epsilon_decay = 0.0005

        # 总共的学习步数
        self.learn_step_counter = 0

        # 初始化记录，n_features*2+2是因为[s,a,r,s_]中a和r各占1
        self.memory = np.zeros((self.memory_size,n_features*2+2))

        self._build_net()

        t_params = tf.compat.v1.get_collection(tf.compat.v1.GraphKeys.GLOBAL_VARIABLES, scope='target_net')
        e_params = tf.compat.v1.get_collection(tf.compat.v1.GraphKeys.GLOBAL_VARIABLES, scope='eval_net')

        with tf.compat.v1.variable_scope('hard_replacement'):
            self.target_replace_op = [tf.compat.v1.assign(t,e) for t,e in zip(t_params,e_params)]

        self.sess = tf.compat.v1.Session()

        if output_graph:
            tf.compat.v1.summary.FileWriter("logs/", self.sess.graph)

        self.sess.run(tf.compat.v1.global_variables_initializer())
        self.cost_his = []

    def _build_net(self):
        # -------------------------------------all inputs------------------------------------------
        tf.compat.v1.disable_eager_execution()
        self.s = tf.compat.v1.placeholder(tf.float32,[None,self.n_features],name='s')
        self.s_ = tf.compat.v1.placeholder(tf.float32,[None,self.n_features],name='s_')
        self.r = tf.compat.v1.placeholder(tf.float32,[None,],name='r')
        self.a = tf.compat.v1.placeholder(tf.int32,[None,],name='a')

        w_initializer, b_initializer = tf.random_normal_initializer(0., 0.3), tf.constant_initializer(0.1)

        # -------------------------------- build evaluate_net -------------------------------------
        with tf.compat.v1.variable_scope('eval_net'):
            e1 = tf.compat.v1.layers.dense(inputs=self.s,units=20,activation=tf.nn.relu,kernel_initializer=w_initializer,bias_initializer=b_initializer,name='e1')
            self.q_eval = tf.compat.v1.layers.dense(e1,self.n_actions,kernel_initializer=w_initializer,bias_initializer=b_initializer,name='q')

         # -------------------------------- build target_net -------------------------------------
        with tf.compat.v1.variable_scope('target_net'):
            t1 = tf.compat.v1.layers.dense(self.s_,20,tf.nn.relu,kernel_initializer=w_initializer,bias_initializer=b_initializer,name='t1')
            self.q_next = tf.compat.v1.layers.dense(t1,self.n_actions,kernel_initializer=w_initializer,bias_initializer=b_initializer,name='t2')

        with tf.compat.v1.variable_scope('q_target'):
            q_target = self.r +self.gamma * tf.reduce_max(self.q_next,axis=1,name='Qmax_s_')
            self.q_target = tf.stop_gradient(q_target)

        with tf.compat.v1.variable_scope('q_eval'):
            a_indices = tf.stack([tf.range(tf.shape(self.a)[0],dtype=tf.int32),self.a],axis=1)
            self.q_eval_wrt_a = tf.gather_nd(params=self.q_eval,indices=a_indices)

        with tf.compat.v1.variable_scope('loss'):
            self.loss = tf.reduce_mean(tf.compat.v1.squared_difference(self.q_target,self.q_eval_wrt_a,name='TD_error'))

        with tf.compat.v1.variable_scope('train'):
            self._train_op = tf.compat.v1.train.RMSPropOptimizer(self.lr).minimize(self.loss)

    def store_transition(self,s,a,r,s_):
        if not hasattr(self,'memory_counter'):
            self.memory_counter = 0
        a = np.array([a])
        transition = np.hstack((s, a, r, s_))
        index = self.memory_counter % self.memory_size
        self.memory[index,:] = transition
        self.memory_counter += 1


    def choose_action(self,observation):
        observation_ = observation[np.newaxis,:]
        if  np.random.uniform() < self.epsilon:
            action_value = self.sess.run(self.q_eval,feed_dict={self.s:observation_})
            action_value = action_value - np.min(action_value)
            action = np.argmax(action_value*observation)
        else:
            temp = []
            for i in range(len(observation)):
                if observation[i] == 1:
                    temp.append(i)
            if temp != []:
                action = random.sample(temp,1)[0]
            else:
                action = np.random.randint(0,self.n_actions)

        return action


    def choose_random_action(self,observation):
        observation = observation[np.newaxis, :]
        action_value = self.sess.run(self.q_eval, feed_dict={self.s: observation})
        action = np.argmax(action_value)

        return action

    def eval(self,observation):
        observation_ = observation[np.newaxis, :]
        action_value = self.sess.run(self.q_eval, feed_dict={self.s: observation_})
        action_value = action_value - np.min(action_value)
        action = np.argmax(action_value * observation)
        return action

    def learn(self):
        # 判断是否到了需要更新target网络的步数
        if self.learn_step_counter % self.replace_target_iter == 0:
            self.sess.run(self.target_replace_op)

        # 从memory中采样出一个batch的memory
        if self.memory_counter > self.memory_size:
            sample_index = np.random.choice(self.memory_size,size=self.batch_size)
        else:
            sample_index = np.random.choice(self.memory_counter,size=self.batch_size)

        batch_memory = self.memory[sample_index,:]

        _,cost = self.sess.run([self._train_op,self.loss],
                               feed_dict={
                                   self.s:batch_memory[:,:self.n_features],
                                   self.a:batch_memory[:,self.n_features],
                                   self.r:batch_memory[:,self.n_features+1],
                                   self.s_:batch_memory[:,-self.n_features:],
                               })

        self.cost_his.append(cost)

        self.epsilon = self.epsilon - self.epsilon_increment if self.epsilon > 0.0001 else 0
        self.learn_step_counter += 1


    def plot_cost(self, save=True):
        if save == True:
            with open("data/choose_random_action_100.txt","w") as f:
                for i in self.cost_his:
                    f.write(str(i)+'\t')
        # 绘制训练误差曲线
        plt.plot(self.cost_his, color='#66CCCC')
        plt.xlabel('Training Steps', fontsize=12, fontname='Times New Roman')
        plt.ylabel('Cost', fontsize=12, fontname='Times New Roman')
        plt.title('Training Cost', fontsize=14, fontweight='bold', fontname='Times New Roman')
        plt.tick_params(labelsize=10)
        plt.grid(linestyle='--', linewidth=0.5, axis='y')
        if save:
            plt.savefig('training_cost.png', dpi=300, bbox_inches='tight')
        plt.show()


