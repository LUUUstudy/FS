import os
import time
import shutil
import numpy as np
import pandas as pd
from tool import Tool
from rnn import RNN
from dnn import DNN
from lstm import LSTM
from prediction_DL import Prediction
from keras.models import load_model

class PredictModel():
    def __init__(self, state, train_data, train_label, test_data, test_label):

        self.state = state
        self.train_data = train_data
        self.train_label = train_label
        self.test_data = test_data
        self.test_label = test_label

        return

    def train_features_select(self):
        train_data = pd.DataFrame()

        # 取出前24列（如果第一列为1的话）
        if self.state[0] == 1:
            train_data = self.train_data.iloc[:, :24]
        else:
            train_data = pd.DataFrame(np.zeros((len(self.train_data), 24)))

        # 取出后12列与后12维度的对应数据
        for i in range(1, 13):
            if self.state[i] == 1:
                if train_data.empty:
                    train_data = self.train_data.iloc[:, 24 + i - 1:24 + i]
                else:
                    train_data = pd.concat([train_data, self.train_data.iloc[:, 24 + i - 1:24 + i]], axis=1)
            else:
                if train_data.empty:
                    train_data = pd.DataFrame(np.zeros((len(self.train_data), 1)))
                else:
                    train_data = pd.concat([train_data, pd.DataFrame(np.zeros((len(self.train_data), 1)))], axis=1)

        return train_data

    def test_features_select(self):
        test_data = pd.DataFrame()

        # 取出前24列（如果第一列为1的话）
        if self.state[0] == 1:
            test_data = self.test_data.iloc[:, :24]
        else:
            test_data = pd.DataFrame(np.zeros((len(self.test_data), 24)))

        # 取出后12列与后12维度的对应数据
        for i in range(1, 13):
            if self.state[i] == 1:
                if test_data.empty:
                    test_data = self.test_data.iloc[:, 24 + i - 1:24 + i]
                else:
                    test_data = pd.concat([test_data, self.test_data.iloc[:, 24 + i - 1:24 + i]], axis=1)
            else:
                if test_data.empty:
                    test_data = pd.DataFrame(np.zeros((len(self.test_data), 1)))
                else:
                    test_data = pd.concat([test_data, pd.DataFrame(np.zeros((len(self.test_data), 1)))], axis=1)

        return test_data


    def lstm_pedict_model(self, n_hidden, learning_rata, epochs, verbose, batch_size):
        # 标准化
        filename_log = ""
        # data_train = PredictModel(self.state, self.train_data,self.train_label,self.test_data,self.test_label).\
        #     train_features_select()
        # data_test = PredictModel(self.state, self.train_data,self.train_label,self.test_data,self.test_label).\
        #     test_features_select()

        data_train_scale, data_test_scale = Tool(filename_log).normalization(data_train=self.train_data, data_test=self.test_data)

        data_train_scale = data_train_scale.to_numpy()
        data_test_scale = data_test_scale.to_numpy()
        self.train_label = self.train_label.to_numpy()
        self.test_label = self.test_label.to_numpy()

        # 增加维度
        data_train_scale = data_train_scale[..., np.newaxis]
        data_test_scale = data_test_scale[..., np.newaxis]

        iteration_start = 0
        iteration_end = 1

        METHOD_STR = "LSTM"
        dir = os.getcwd()
        dir_method = dir + '\\experiments\\' + METHOD_STR + '\\' + METHOD_STR + '_index='

        print(METHOD_STR, "is running ...")

        for index in np.arange(iteration_start, iteration_end):
            # print()
            # print("**************************** [index_iteration]:", index, "********************************")
            # print()

            dir_choose = dir_method + str(index)
            if os.path.exists(dir_choose):
                shutil.rmtree(dir_choose)
            os.makedirs(dir_choose)

            filename_log = "log.txt"
            file_log = open(dir_choose + "\\" + filename_log, 'w')
            file_log.write( " ---- " + METHOD_STR + "\n\n")

            if METHOD_STR == "LSTM":
                METHOD = LSTM
            elif METHOD_STR == "RNN":
                METHOD = RNN
            elif METHOD_STR == "DNN":
                METHOD = DNN

            model, history = METHOD(data_train=data_train_scale, label_train=self.train_label). \
                trainModel(n_hidden=n_hidden, learning_rate=learning_rata, epochs=epochs, verbose=verbose)

            predict_test = Prediction(data_test=data_test_scale, label_test=self.test_label). \
                prediction(model=model, batch_size=batch_size)

            # 记录结果，保存实验数据：mae_train, prediction_test, actual_test
            mae_train = history.history['loss']
            actual_test = self.test_label  # 记录测试集真实数据
            save_data_list = [mae_train, predict_test, actual_test]
            save_data_filename = ['mae_train.csv', 'predict_test.csv', 'actual_test.csv']

            for j in range(len(save_data_list)):
                data_temp = pd.DataFrame(save_data_list[j])
                data_temp_filename = "\\" + save_data_filename[j]
                if os.path.exists(data_temp_filename):  # 文件存在则删除，不存在就写入
                    os.remove(data_temp_filename)
                data_temp.to_csv(data_temp_filename, index=False, header=None)

            # 计算指标
            file_log.write("\n学习率：" + str(learning_rata) + '\n')
            print("测试集各项指标：")
            # file_log.write("====================================================================\n")
            file_log.write("测试集各项指标：\n")
            mae = Tool(file_log).mae(action_predict=predict_test, action_true=actual_test)
            mape = Tool(file_log).mape(action_predict=predict_test, action_true=actual_test)
            rmse = Tool(file_log).rmse(action_predict=predict_test, action_true=actual_test)
            cv = Tool(file_log).cv(action_predict=predict_test, action_true=actual_test)
            r2 = Tool(file_log).r2(action_predict=predict_test, action_true=actual_test)

        return

    def lstm_predict(self, batch_size, learning_rate,model):
        # 标准化
        filename_log = ""

        data_train = PredictModel(self.state, self.train_data,self.train_label,self.test_data,self.test_label).\
            train_features_select()
        data_test = PredictModel(self.state, self.train_data,self.train_label,self.test_data,self.test_label).\
            test_features_select()

        data_train_scale, data_test_scale = Tool(filename_log).normalization(data_train=data_train, data_test=data_test)

        data_train_scale = data_train_scale.to_numpy()
        data_test_scale = data_test_scale.to_numpy()
        self.train_label = self.train_label.to_numpy()
        self.test_label = self.test_label.to_numpy()

        #增加维度
        data_train_scale = data_train_scale[..., np.newaxis]
        data_test_scale = data_test_scale[..., np.newaxis]

        iteration_start = 0
        iteration_end = 1

        METHOD_STR = "LSTM"
        dir = os.getcwd()
        dir_method = dir + '\\experiments\\' + METHOD_STR + '\\' + METHOD_STR + '_index='

        for index in np.arange(iteration_start, iteration_end):

            dir_choose = dir_method + str(index)
            if os.path.exists(dir_choose):
                shutil.rmtree(dir_choose)
            os.makedirs(dir_choose)

            filename_log = "log.txt"
            file_log = open(dir_choose + "\\" + filename_log, 'w')
            file_log.write( " ---- " + METHOD_STR + "\n\n")

            if METHOD_STR == "LSTM":
                METHOD = LSTM
            elif METHOD_STR == "RNN":
                METHOD = RNN
            elif METHOD_STR == "DNN":
                METHOD = DNN

            # model, history = METHOD(data_train=data_train_scale, label_train=label_train). \
            #     trainModel(n_hidden=n_hidden, learning_rate=learning_rate, epochs=epochs, verbose=verbose)

            # model = load_model('lstm_model_last.h5')

            predict_test = Prediction(data_test=data_test_scale, label_test=self.test_label). \
                prediction(model=model, batch_size=batch_size)

            # 记录结果，保存实验数据：mae_train, prediction_test, actual_test
            # mae_train = history.history['loss']
            actual_test = self.test_label  # 记录测试集真实数据
            save_data_list = [predict_test, actual_test]
            save_data_filename = ['predict_test.csv', 'actual_test.csv']

            for j in range(len(save_data_list)):
                data_temp = pd.DataFrame(save_data_list[j])
                data_temp_filename = "\\" + save_data_filename[j]
                if os.path.exists(data_temp_filename):  # 文件存在则删除，不存在就写入
                    os.remove(data_temp_filename)
                data_temp.to_csv(dir_choose + data_temp_filename, index=False, header=None)

            # 计算指标
            file_log.write("\n学习率：" + str(learning_rate) + '\n')
            # print("测试集各项指标：")
            # file_log.write("====================================================================\n")
            file_log.write("测试集各项指标：\n")
            mae = Tool(file_log).mae(action_predict=predict_test, action_true=actual_test)
            # mape = Tool(file_log).mape(action_predict=predict_test, action_true=actual_test)
            # rmse = Tool(file_log).rmse(action_predict=predict_test, action_true=actual_test)
            # cv = Tool(file_log).cv(action_predict=predict_test, action_true=actual_test)
            # r2 = Tool(file_log).r2(action_predict=predict_test, action_true=actual_test)
            mae = -mae

        return mae


