import warnings
warnings.filterwarnings("ignore")
with warnings.catch_warnings():
    warnings.filterwarnings("ignore",category=DeprecationWarning)

import sklearn
from DQN import DeepQNetwork
from Environment import DataLoad, Environment
from predictmodel import PredictModel
import pandas as pd
import time
import csv
import tensorflow as tf
from keras.models import load_model


reward_list = []
reward_list.append(18)

def run(agent,env,episodes):
    if not isinstance(agent,DeepQNetwork) or not isinstance(env,Environment):
        raise KeyError('input error')
    step = 0
    Rewards_all = []
    array_list = []
    for episode in range(episodes):

        observation = env.reset()
        episode_reward = 0
        reward_1 = 0


        while True:
            action = agent.choose_action(observation)
            observation_, reward, done, _ = env.step(action)
            # if done:
            #     if reward > max(reward_list, default=float('inf')):
            #         reward_1 = reward - max(reward_list, default=float('inf'))
            #     elif reward == max(reward_list, default=float('inf')):
            #         reward_1 = 0
            #     else:
            #         reward_1 = reward - max(reward_list, default=float('inf'))
            #     reward_list.append(reward)
            # reward = reward + reward_1
            agent.store_transition(observation,action,reward,observation_)
            episode_reward += reward

            if (step > 200) and (step % 5 == 0):
                print('After {} steps, learn!'.format(step))
                agent.learn()
            observation = observation_

            if done:
                print('for {} episode,break!'.format(episode))
                print('该回合rewards为{}'.format(episode_reward))
                Rewards_all.append(episode_reward)
                array_list.append(observation_)
                print('*************结束************')
                break
            step += 1
    print('run over!')
    # with open('data/results.csv', 'w', newline='') as file:
    #     writer = csv.writer(file)
    #     writer.writerow(["Reward"])
    #     for reward in Rewards_all:
    #         writer.writerow([reward])
    with open('data/Rewards_all.csv', 'a', encoding='utf-8') as f:
        for i in Rewards_all:
            f.write(str(i))
            f.write('\t')
            f.write('\n')
    f.close()
    with open('data/array_list.csv', 'a', encoding='utf-8') as f:
        for i in array_list:
            f.write(str(i))
            f.write('\t')
            f.write('\n')
    f.close()


if __name__=='__main__':
    tf.compat.v1.disable_eager_execution()           # 关闭eager execution模式
    model = load_model('lstm_model_last.h5')
    env = Environment(13 , r'data/train.csv', r'data/train1.csv', model)
    agent = DeepQNetwork(env.n_action,env.total_feature_num,
                         learning_rate=0.05,
                         e_greedy=0.9,
                         replace_target_iter= 300,
                         memory_size=1000)
    # PredictModel(env.state,env.train_data,env.train_label,env.test_data,env.test_label).\
    #     lstm_pedict_model(n_hidden=32, learning_rata=0.004, epochs=50, verbose=1, batch_size=32)

    start = time.time()
    run(agent,env,400)
    end = time.time()
    print('Time Cost:',end-start)
    agent.plot_cost(save=True)
    # eval(agent, env, [1, 3, 5, 6, 7, 8, 9, 13])